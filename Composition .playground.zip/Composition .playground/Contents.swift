import UIKit
//composition
class Kategoriler {
    var kategori_id:Int?
    var kategori_ad:String?
    
    init(kategori_id:Int, kategori_ad:String){
        self.kategori_id = kategori_id
        self.kategori_ad = kategori_ad

    }
}

class Yonetmenler {
    var yonetmen_id:Int?
    var yonetmen_ad:String?
    
    init(yonetmen_id:Int, yonetmen_ad:String){
        self.yonetmen_ad = yonetmen_ad
        self.yonetmen_id = yonetmen_id
    }
}

class Filmler {
    var film_id:Int?
    var film_yil:Int?
    var film_ad:String?
    var kategori:Kategoriler? // alttaki ve bu satır sayesinde artık ek bir tanımlama yapmadan önceki kategoriler ve yönetmenler sınıfı içinde belirlediğimiz tablolara da erişebileceğiz. Bunu ek bir işlem yapmadan yapabilme kısmına da composition denir.
    var yonetmen:Yonetmenler?
    init (film_id:Int, film_ad:String, film_yil:Int, kategori:Kategoriler, yonetmen:Yonetmenler){
        self.film_ad = film_ad
        self.film_id = film_id
        self.film_yil = film_yil
        self.kategori = kategori
        self.yonetmen = yonetmen
    }
}

let k1 = Kategoriler(kategori_id: 1, kategori_ad: "Dram")
let k2 = Kategoriler(kategori_id: 2, kategori_ad: "Komedi")

let y1 = Yonetmenler(yonetmen_id: 1, yonetmen_ad: "Quentin Tarantino")
let y2 = Yonetmenler(yonetmen_id: 2, yonetmen_ad: "Christopher Nolan")

let f1 = Filmler(film_id: 1, film_ad: "Cango", film_yil: 2013, kategori: k1, yonetmen: y1)
let f2 = Filmler(film_id: 2, film_ad: "Özlenenler", film_yil: 2005, kategori: k2, yonetmen: y2)


print("Film_id       : \(f1.film_id!)")
print("Film_ad       : \(f1.film_ad!)")
print("Film_yil      : \(f1.film_yil!)")
print("Film_kategori : \(f1.kategori!.kategori_ad!)")

// bu alanda f1 dediğimiz zaman yukarıda yer alan k1 alanına erişim sağlarız,

print("Film_yonetmen : \(f1.yonetmen!.yonetmen_ad!)")

// bu alanda f1 dediğimiz zaman yukarıda yer alan y1 alanına erişim sağlarız,




print("Film_id       : \(f2.film_id!)")
print("Film_ad       : \(f2.film_ad!)")
print("Film_yil      : \(f2.film_yil!)")
print("Film_kategori : \(f2.kategori!.kategori_ad!)")

// bu alanda f1 dediğimiz zaman yukarıda yer alan k2 alanına erişim sağlarız,

print("Film_yonetmen : \(f2.yonetmen!.yonetmen_ad!)")

// bu alanda f1 dediğimiz zaman yukarıda yer alan y2 alanına erişim sağlarız,

